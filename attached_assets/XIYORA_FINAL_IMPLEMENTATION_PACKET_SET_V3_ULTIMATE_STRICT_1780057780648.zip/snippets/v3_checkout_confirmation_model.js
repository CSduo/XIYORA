// XIYORA V3 Checkout Confirmation Model
// Adapt into existing state/store. This is a logic model, not a full replacement.

export const emptyCheckoutConfirmation = {
  customerDraft: {
    name: "",
    phone: "",
    email: "",
    buyerType: "",
    companyName: "",
    city: "",
    state: "",
    pincode: ""
  },
  confirmedCustomer: null,
  confirmedLocation: null,
  isDetailsConfirmed: false,
  isLocationConfirmed: false,
  estimateStatus: "draft", // draft | confirmed | needs_reconfirmation | quote_required
};

export function validateCustomerDraft(draft) {
  const errors = {};

  if (!draft.name?.trim()) errors.name = "Full name is required.";
  if (!draft.phone?.trim() || draft.phone.replace(/\D/g, "").length < 10) {
    errors.phone = "Valid WhatsApp number is required.";
  }
  if (draft.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.email)) {
    errors.email = "Enter a valid email or leave it blank.";
  }
  if (!draft.city?.trim()) errors.city = "City is required.";
  if (!draft.state?.trim()) errors.state = "State is required.";
  if (!/^\d{6}$/.test(String(draft.pincode || "").trim())) {
    errors.pincode = "Enter a valid 6-digit Indian pincode.";
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}

export function confirmCheckoutDetails(state, deliveryEstimate) {
  const validation = validateCustomerDraft(state.customerDraft);
  if (!validation.valid) {
    return { ...state, errors: validation.errors, isDetailsConfirmed: false };
  }

  const confirmedCustomer = { ...state.customerDraft, confirmedAt: new Date().toISOString() };

  const next = {
    ...state,
    confirmedCustomer,
    confirmedLocation: deliveryEstimate,
    isDetailsConfirmed: true,
    isLocationConfirmed: Boolean(deliveryEstimate),
    estimateStatus: deliveryEstimate?.quoteRequired ? "quote_required" : "confirmed",
    errors: {}
  };

  localStorage.setItem("xiyora_confirmed_checkout", JSON.stringify(next));
  return next;
}

export function markNeedsReconfirmation(state) {
  return {
    ...state,
    isDetailsConfirmed: false,
    isLocationConfirmed: false,
    estimateStatus: "needs_reconfirmation"
  };
}

export function canEnableUpiPayment(state, cart) {
  return Boolean(
    state.isDetailsConfirmed &&
    state.isLocationConfirmed &&
    state.estimateStatus === "confirmed" &&
    cart?.items?.length > 0 &&
    cart?.totalINR > 0
  );
}
