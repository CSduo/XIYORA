// XIYORA V3 WhatsApp Popup Logic Snippet
// Adapt names/imports to the existing project structure.

import React, { useEffect, useMemo, useState } from "react";

const WHATSAPP_NUMBER = "917028311226";

function buildWhatsAppUrl(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function XiyoraWhatsAppPopup({ context = {}, page = "home" }) {
  const [visible, setVisible] = useState(false);

  const message = useMemo(() => {
    if (page === "checkout") {
      return [
        "Hello XIYORA, I want to confirm my estimate.",
        context.product ? `Product: ${context.product}` : "",
        context.variant ? `Variant/SKU: ${context.variant}` : "",
        context.quantity ? `Quantity: ${context.quantity}` : "",
        context.city ? `City: ${context.city}` : "",
        context.total ? `Estimated total: ${context.total}` : "",
        "Please confirm availability and proforma."
      ].filter(Boolean).join("\n");
    }

    if (page === "product") {
      return [
        "Hello XIYORA, I am interested in this product.",
        context.product ? `Product: ${context.product}` : "",
        context.variant ? `Variant: ${context.variant}` : "",
        "Please share details and proforma."
      ].filter(Boolean).join("\n");
    }

    return "Hello XIYORA, I want help choosing premium latex products. Please share catalogue and guidance.";
  }, [context, page]);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("xiyora_whatsapp_popup_dismissed");
    if (dismissed) return;

    const timer = setTimeout(() => setVisible(true), 9000);

    const onScroll = () => {
      const scrollRatio = window.scrollY / Math.max(document.body.scrollHeight - window.innerHeight, 1);
      if (scrollRatio > 0.38) setVisible(true);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      clearTimeout(timer);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  if (!visible) return null;

  return (
    <aside className="xiyora-whatsapp-popup" role="dialog" aria-label="XIYORA WhatsApp help">
      <button
        aria-label="Close WhatsApp help"
        onClick={() => {
          sessionStorage.setItem("xiyora_whatsapp_popup_dismissed", "1");
          setVisible(false);
        }}
      >
        ×
      </button>
      <strong>Need help choosing latex comfort?</strong>
      <p>Share your size, city, and product interest — we’ll help with a proforma.</p>
      <div>
        <a href={buildWhatsAppUrl(message)} target="_blank" rel="noreferrer">
          WhatsApp XIYORA
        </a>
        <a href="/documents">Request Catalogue</a>
      </div>
    </aside>
  );
}
