XIYORA FINAL IMPLEMENTATION PACKET SET — V3 ULTIMATE STRICT

This V3 package builds on the V2 Strict package and adds the final layer of premium UI, interaction design, basket/wishlist refinement, WhatsApp popup behavior, checkout confirmation discipline, form-prefill rules, advanced animation rules, product-selection quality rules, and final no-error builder enforcement.

Use this V3 package as the final package.

IMPORTANT:
- Start with README_FIRST_READ_ME.txt if present.
- Then read this V3 README.
- Then read all files beginning with 00, especially the V3 files.
- Then apply Phase 1 core changes first.
- Do not apply final image replacement until final visuals are confirmed by the user.
- Replit/Kimi must not invent pricing, logistics, certificates, image mapping, or supplier claims.
- The builder only applies our prepared data, UI rules, and implementation specs.
- The builder must scan → apply → build → fix → verify after each phase.

V3 added files:
- 00D_V3_ULTIMATE_PREMIUM_UI_STANDARD.txt
- 00E_V3_INTERACTIVE_HERO_VIDEO_AND_WHATSAPP_POPUP.txt
- 00F_V3_BASKET_WISHLIST_AND_CHECKOUT_CONFIRMATION.txt
- 00G_V3_FORM_PREFILL_AND_CUSTOMER_DATA_CONFIRMATION.txt
- 00H_V3_PRODUCT_SELECTION_AND_CUSTOMER_BEST_FIT_RULES.txt
- 00I_V3_ADVANCED_ANIMATION_MICROINTERACTION_SYSTEM.txt
- 00J_V3_FINAL_BUILDER_ERROR_FIX_AND_PROOF_PROTOCOL.txt
- 15B_REPLIT_PROMPT_V3_FINAL_ULTIMATE_APPLY.txt
- snippets/v3_premium_motion_css.css
- snippets/v3_whatsapp_popup_logic.jsx
- snippets/v3_checkout_confirmation_model.js
- config/v3_customer_best_fit_product_rules.json
- qa/v3_final_acceptance_matrix.csv

This V3 version is stricter than V2. It adds final aesthetic and UX expectations:
- Premium video as the first visual experience.
- Interactive WhatsApp support popup, not only a floating icon.
- Basket with wishlist/saved items.
- Checkout details confirmation before payment/proforma.
- Form fields can show helpful examples but must not submit placeholder data.
- Strong premium UI rules for mobile and desktop.
- Advanced but tasteful animation system.
- Better “best product for customer” guidance.
- Builder must immediately fix any error it detects.
