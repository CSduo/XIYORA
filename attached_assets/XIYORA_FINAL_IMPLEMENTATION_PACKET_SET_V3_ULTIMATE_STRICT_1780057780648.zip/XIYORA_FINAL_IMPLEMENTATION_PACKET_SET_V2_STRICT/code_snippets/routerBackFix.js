export function navigateInternal(path, state = {}) {
  window.history.pushState({ xiyoraInternal: true, ...state }, "", path);
  window.dispatchEvent(new CustomEvent("xiyora:navigate", { detail: { path, state } }));
}

export function setupInternalBackHandler(onRoute) {
  window.addEventListener("popstate", (event) => {
    const path = window.location.pathname + window.location.search;
    onRoute?.(path, event.state || {});
  });
}

export function breadcrumbToCategory(categorySlug) {
  navigateInternal(`/category/${categorySlug}`, { categorySlug });
}
