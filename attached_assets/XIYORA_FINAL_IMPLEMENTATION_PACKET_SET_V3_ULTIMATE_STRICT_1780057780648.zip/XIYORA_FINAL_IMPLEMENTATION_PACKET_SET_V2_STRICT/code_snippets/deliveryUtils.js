import { DELIVERY_CONFIG } from "./deliveryConfig";

export function getPackageCount(quantity, unitsPerPackage = 1) {
  const q = Math.max(1, Number(quantity) || 1);
  const units = Math.max(1, Number(unitsPerPackage) || 1);
  return Math.ceil(q / units);
}

export function classifyRegion({ state = "", city = "", pincode = "" }) {
  const s = state.toLowerCase();
  const c = city.toLowerCase();

  if (["maharashtra"].includes(s)) {
    if (["mumbai", "navi mumbai", "thane", "pune"].some(x => c.includes(x))) {
      return { region: "west", band: "nearPortLocalMetro", routing: "Nhava Sheva / Mumbai + local delivery" };
    }
    return { region: "west", band: "sameStateNearZone", routing: "Nhava Sheva / Mumbai + inland delivery" };
  }

  if (["telangana", "andhra pradesh"].includes(s)) {
    return { region: "south", band: "interstateMajorCity", routing: "Chennai / Visakhapatnam region + inland delivery" };
  }

  if (["assam", "meghalaya", "manipur", "mizoram", "nagaland", "tripura", "arunachal pradesh", "sikkim"].includes(s)) {
    return { region: "northeast", band: "interiorRemote", routing: "Kolkata / Haldia + inland delivery" };
  }

  if (["tamil nadu", "kerala", "karnataka"].includes(s)) {
    return { region: "south", band: "interstateMajorCity", routing: "Chennai / Kochi / Tuticorin region + inland delivery" };
  }

  if (["west bengal", "odisha", "bihar", "jharkhand"].includes(s)) {
    return { region: "east", band: "interstateMajorCity", routing: "Kolkata / Haldia / Paradip region + inland delivery" };
  }

  return { region: "unknown", band: "interstateMajorCity", routing: "Nearest available Indian port/region + inland delivery" };
}

export function estimateDeliveryINR({ packageType = "smallParcel", quantity = 1, unitsPerPackage = 1, state, city, pincode }) {
  const packageCount = getPackageCount(quantity, unitsPerPackage);
  const location = classifyRegion({ state, city, pincode });
  const typeConfig = DELIVERY_CONFIG.packageTypes[packageType] || DELIVERY_CONFIG.packageTypes.smallParcel;
  const bandValue = typeConfig.bands[location.band];

  if (bandValue === "QUOTE_REQUIRED") {
    return { quoteRequired: true, packageCount, routing: location.routing, label: "Quote required" };
  }

  const [min, max] = bandValue;
  const first = min;
  const extraMultiplier = packageType === "smallParcel" ? 0.5 : packageType === "mediumParcel" ? 0.65 : null;

  if (extraMultiplier === null && packageCount > 1) {
    return { quoteRequired: true, packageCount, routing: location.routing, label: "Quote required for bulky multiple packages" };
  }

  const extra = packageCount > 1 ? Math.round(first * extraMultiplier * (packageCount - 1)) : 0;
  const estimate = first + extra;

  return {
    quoteRequired: false,
    packageCount,
    routing: location.routing,
    deliveryHandlingINR: estimate,
    deliveryRangeINR: [min, max],
    label: `₹${estimate.toLocaleString("en-IN")} estimated domestic handling`,
  };
}
