export const DELIVERY_CONFIG = {
  businessRule:
    "Product price is already India landed/customer-facing estimate. Add only domestic delivery/location handling.",
  packageTypes: {
    smallParcel: {
      examples: ["pillows", "small cushions", "accessories"],
      unitsPerPackageDefault: 2,
      bands: {
        nearPortLocalMetro: [100, 300],
        sameStateNearZone: [200, 600],
        interstateMajorCity: [400, 1000],
        interiorRemote: [700, 1800],
        veryRemoteCustom: "QUOTE_REQUIRED",
      },
    },
    mediumParcel: {
      examples: ["toppers", "folded/rolled latex items", "multiple pillows"],
      unitsPerPackageDefault: 1,
      bands: {
        nearPortLocalMetro: [500, 1500],
        sameStateNearZone: [800, 2500],
        interstateMajorCity: [1500, 4500],
        interiorRemote: [2500, 7000],
        veryRemoteCustom: "QUOTE_REQUIRED",
      },
    },
    bulkyParcel: {
      examples: ["mattresses", "large toppers", "custom/bay-window products"],
      unitsPerPackageDefault: 1,
      bands: {
        nearPortLocalMetro: [1500, 4000],
        sameStateNearZone: [2500, 7000],
        interstateMajorCity: [4000, 12000],
        interiorRemote: "QUOTE_REQUIRED",
        veryRemoteCustom: "QUOTE_REQUIRED",
      },
    },
  },
  ports: {
    west: ["Nhava Sheva / Mumbai", "Mundra", "Kandla"],
    south: ["Chennai", "Ennore", "Kattupalli", "Kochi", "Tuticorin"],
    east: ["Kolkata", "Haldia", "Paradip", "Visakhapatnam"],
    northeast: ["Kolkata / Haldia + inland delivery"],
  },
};
