export const CURRENCY_CONFIG = {
  baseCurrency: "INR",
  checkoutFinalCurrency: "INR",
  note: "Currency conversion is indicative. Final proforma/payment is confirmed in INR unless otherwise stated.",
  currencies: {
    INR: { symbol: "₹", label: "INR", name: "Indian Rupee", rateFromINR: 1 },
    USD: { symbol: "$", label: "USD", name: "US Dollar", rateFromINR: null },
    AED: { symbol: "د.إ", label: "AED", name: "UAE Dirham", rateFromINR: null },
    EUR: { symbol: "€", label: "EUR", name: "Euro", rateFromINR: null },
    GBP: { symbol: "£", label: "GBP", name: "British Pound", rateFromINR: null },
    SGD: { symbol: "S$", label: "SGD", name: "Singapore Dollar", rateFromINR: null },
    AUD: { symbol: "A$", label: "AUD", name: "Australian Dollar", rateFromINR: null },
  },
};

export function formatMoneyINR(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value || 0);
}

export function convertFromINR(amountINR, currencyCode, adminRates = {}) {
  const cfg = CURRENCY_CONFIG.currencies[currencyCode] || CURRENCY_CONFIG.currencies.INR;
  const rate = currencyCode === "INR" ? 1 : adminRates[currencyCode] || cfg.rateFromINR;
  if (!rate) return { amount: amountINR, code: "INR", fallback: true };
  return { amount: Math.round((amountINR || 0) * rate), code: currencyCode, fallback: false };
}
