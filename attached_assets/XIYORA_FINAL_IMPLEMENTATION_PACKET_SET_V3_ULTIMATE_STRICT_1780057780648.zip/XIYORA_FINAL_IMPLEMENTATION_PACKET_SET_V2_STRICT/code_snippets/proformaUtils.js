export function createOrderId(prefix = "XIYORA") {
  const now = new Date();
  const stamp = now.toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
  return `${prefix}-${stamp}`;
}

export function buildProforma(order) {
  return {
    documentType: "Proforma / Estimate",
    notGSTInvoice: true,
    orderId: order.orderId || createOrderId(),
    date: new Date().toLocaleDateString("en-IN"),
    customer: order.customer,
    items: order.items,
    packageCount: order.packageCount,
    productSubtotalINR: order.productSubtotalINR,
    domesticDeliveryHandlingINR: order.domesticDeliveryHandlingINR,
    estimatedTotalINR: order.estimatedTotalINR,
    routing: order.routing,
    paymentMethod: order.paymentMethod || "Proforma / WhatsApp confirmation",
    note:
      "This is an indicative proforma. Final invoice/payment confirmation may depend on availability, city, quantity, and final dispatch confirmation.",
  };
}

export function buildUpiLink({ totalINR, orderId }) {
  if (!totalINR || totalINR <= 0) return "";
  const pa = "chaitanyagaikwad022@okicici";
  const pn = "XIYORA";
  const tn = `XIYORA Order ${orderId || ""}`.trim();
  return `upi://pay?pa=${encodeURIComponent(pa)}&pn=${encodeURIComponent(pn)}&am=${encodeURIComponent(totalINR)}&cu=INR&tn=${encodeURIComponent(tn)}`;
}
