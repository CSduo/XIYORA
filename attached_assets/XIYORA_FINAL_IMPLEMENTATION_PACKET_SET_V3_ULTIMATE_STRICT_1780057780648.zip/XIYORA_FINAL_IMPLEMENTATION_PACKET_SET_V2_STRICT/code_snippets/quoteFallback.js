export async function submitQuoteWithFallback({ endpoint = "/api/quotes", payload, onSuccess, onFallback }) {
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) throw new Error(`Quote API failed: ${res.status}`);

    const data = await res.json();
    onSuccess?.(data);
    return { ok: true, data };
  } catch (error) {
    console.error("[XIYORA quote fallback]", {
      endpoint,
      error: error?.message || error,
      payloadPreview: payload,
      fallbackTriggered: true,
    });

    const localQuote = {
      ...payload,
      fallbackSavedAt: new Date().toISOString(),
      fallbackReason: error?.message || "Unknown quote API error",
    };

    const existing = JSON.parse(localStorage.getItem("xiyora_quote_fallbacks") || "[]");
    existing.push(localQuote);
    localStorage.setItem("xiyora_quote_fallbacks", JSON.stringify(existing));

    onFallback?.(localQuote);

    return {
      ok: false,
      fallback: true,
      message:
        "Quotation could not be sent online right now. Your proforma is ready below, and you can still send it through WhatsApp or email.",
      localQuote,
    };
  }
}
