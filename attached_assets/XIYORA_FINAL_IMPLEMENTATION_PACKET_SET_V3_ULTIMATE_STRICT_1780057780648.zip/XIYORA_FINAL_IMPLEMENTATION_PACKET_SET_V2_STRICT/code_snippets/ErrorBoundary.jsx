import React from "react";

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("[XIYORA ErrorBoundary]", { error, info });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="xiyora-error-boundary">
          <h2>Something needs refreshing.</h2>
          <p>The page could not load this section properly. Please refresh, or continue through WhatsApp support.</p>
          <button onClick={() => window.location.reload()}>Refresh</button>
          <a href="https://wa.me/917028311226" target="_blank" rel="noreferrer">WhatsApp Support</a>
        </div>
      );
    }

    return this.props.children;
  }
}
