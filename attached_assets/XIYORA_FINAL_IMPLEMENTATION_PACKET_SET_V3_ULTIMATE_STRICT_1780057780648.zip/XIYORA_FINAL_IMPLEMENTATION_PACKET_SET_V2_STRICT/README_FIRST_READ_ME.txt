XIYORA FINAL IMPLEMENTATION PACKET SET — V2 STRICT

Read this file first.

This package is a strict phased implementation system for the XIYORA website upgrade. It exists because previous changes appeared in preview but did not persist correctly to GitHub/imported projects. Therefore, the builder must apply changes to the real files, build, verify, and push/export properly.

USE ORDER:
1. 00A_STRICT_PACKAGE_RECHECK_REPORT.txt
2. 00_APPLY_ORDER_MASTER_PLAN.txt
3. 00B_AI_BUILDER_SCAN_FIX_LOOP_PROTOCOL.txt
4. 00C_LOCKED_SCOPE_AND_NO_INVENTION_RULES.txt
5. 01_BUILDER_OPERATING_RULES.txt
6. 02_FULL_CHANGE_REGISTRY.txt
7. Phase files 03–10 in order
8. 12_REPLIT_PROMPT_PHASE_1_CORE_APPLY.txt
9. 15_REPLIT_PROMPT_V2_STRICT_CORE_APPLY.txt
10. Image Phase 2 only after user confirms final visual assets.

IMPORTANT:
- Phase 1 core changes first.
- Do not randomly replace final images yet.
- Prepare image manifest/folders now.
- Apply actual image mapping only after user confirms visuals.
- Use prepared delivery/currency/proforma configs; do not invent calculations.
- Run build after each major phase.
- Fix errors immediately.
- Push to GitHub or return complete ZIP.

This V2 package adds more sophistication, advanced animation direction, stricter QA gates, and stronger builder error-fix rules.
